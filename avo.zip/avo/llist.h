#ifndef _LIST_
#define _LIST_

#include <stdio.h>
#include <stdlib.h>
#include <assert.h> 
#include <string.h>

#include "data.h"

typedef struct node node_t;    // a list node

struct node {
	data_t *d;
	node_t *next;
};

typedef node_t *list_t;       

list_t createList();                        // creates & returns an empty list
list_t insert(data_t *d, list_t l);         // insert data d into **the front** 
                                            //   of list l, returns the changed list
void search(char *key, list_t l, FILE *f);  // search, as defined in ass1
void free_list(list_t l);                   // destroy list l


#endif
