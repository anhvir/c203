This is Anh's solution for assignment 1.
You can use it for your ass2, but notes:

- although the code has passed all autotest of ass1, 
  there is no guarantee that it is correct, and if
  you use it, you use it with your own risk, Anh won't
  be responsible for any damage

- if you use, please make a proper reference

Enjoy!
