/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemente by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/

#include "result.h"
#include "list.h"



result_t *resultCreate(char *key) {
    result_t *res= malloc(sizeof(*res));
    assert(res);
    res->key= strdup(key); assert(res->key);
    res->bits= res->nodes= res->strings= 0;
    res->soln= NULL;
    return res;
}

void resultPrint(result_t *res, FILE *outFile, FILE *statFile) {
    list_t *soln= res->soln;
    if (soln) 
        fprintf(statFile, "%s --> %zu records found", res->key, listCount(soln));
    else
        fprintf(statFile, "%s --> no records found", res->key);
    fprintf(statFile, " - comparisons: b%zu n%zu s%zu\n",
        res->bits, res->nodes, res->strings);

    // output to outFile
    fprintf(outFile,"%s\n", res->key);
    if (soln) 
        listOutputAll(outFile, soln, "--> ");
    else
        fprintf(outFile, "--> NOT FOUND\n");
}

void resultFree(result_t *res) {
    assert(res);
	if (res->soln) listFreeNoData((list_t *) res->soln);
    if (res->key) free(res->key);
    free(res);
}

void resultFreeNoFreeSoln(result_t *res) {
    assert(res);
    if (res->key) free(res->key);
    free(res);
}



