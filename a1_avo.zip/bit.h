/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemented by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/

/* Number of bits in a single character. */
#define BITS_PER_BYTE 8
#define BYTE2BIT(X)  ((X)<<3)
#define BIT2BYTE(X)  ((X+BITS_PER_BYTE-1)>>3) 

int getBit(const char *s, unsigned int bitIndex);
