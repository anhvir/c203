/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemented by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "data.h"
#include "bit.h"

// Define a global constant for the number of string fields.
// This makes the code more maintainable.
const int NUMBER_OF_STRING_FIELDS = 33;
const int NUMBER_OF_FIELDS = 35; // Total fields, including x and y

// This struct is designed to hold the address data.
// All fields are pointers to character strings (char *), except for x and y
// which are long doubles for coordinate values.
struct data{
	char *PFI;
	char *EZI_ADD;
	char *SRC_VERIF;
	char *PROPSTATUS;
	char *GCODEFEAT;
	char *LOC_DESC;
	char *BLGUNTTYP;
	char *HSAUNITID;
	char *BUNIT_PRE1;
	char *BUNIT_ID1;
	char *BUNIT_SUF1;
	char *BUNIT_PRE2;
	char *BUNIT_ID2;
	char *BUNIT_SUF2;
	char *FLOOR_TYPE;
	char *FLOOR_NO_1;
	char *FLOOR_NO_2;
	char *BUILDING;
	char *COMPLEX;
	char *HSE_PREF1;
	char *HSE_NUM1;
	char *HSE_SUF1;
	char *HSE_PREF2;
	char *HSE_NUM2;
	char *HSE_SUF2;
	char *DISP_NUM1;
	char *ROAD_NAME;
	char *ROAD_TYPE;
	char *RD_SUF;
	char *LOCALITY;
	char *STATE;
	char *POSTCODE;
	char *ACCESSTYPE;
	long double x;
	long double y;
	char *storage;  // the whole input line, with \0 added at the end of each field 
					   // all char * suach as PFI is just a pointer to its starting position      
					   // in this input line. Note that at the end we only need to free line
					   //    no need to free any other string field
};

// define the _KEY field 
#define _KEY EZI_ADD   /* field that is defined as the key */

/* 
	skip the header line of .csv file "f"
	Copied from W3.4
*/
void dataSkipHeaderLine(FILE *infile) {
	while (fgetc(infile) != '\n');
}

char *dataGetKey(data_t *data) {
	return data->_KEY;
}

/*
 * Reads a single line from a file stream, parses it as a CSV data,
 * and creates a new data_t struct. 
 *
 * Input:
	   infile:  A pointer to the FILE stream to read from.
 * Return:
	   A pointer to the newly allocated data_t struct, or NULL on error or EOF.
 * Limitation:
	   A single CSV input line should contain all fields of a data 
	   (that is, no \n allowed inside any field)
	   If a field contains an opening ", it must have a coresponging closing "
 */
data_t *dataBuild(FILE *infile) {
	char *line = NULL;
	size_t len = 0;

	// Use getline to read the line together with allocating memory dynamically.
	if (getline(&line, &len, infile) == -1) {
		if (line) free(line); // Free the buffer allocated by getline on EOF
		return NULL;
	}

	data_t *data = (data_t *)malloc(sizeof(data_t));
	if (!data) {
		fprintf(stderr, "Error: Memory allocation failed for data_t struct.\n");
		free(line);
		free(data);
		return NULL;
	}

	// Assign the dynamically allocated buffer directly to the struct.
	data->storage = line;

	// Pointers to the current position in the line and the start of the field
	char *current = data->storage;
	char *fieldStart;

	// An array of pointers to the string fields in the struct. 
	//    Used for simplifying the code for reading  
	char **fieldPtrs[] = {
		&data->PFI, &data->EZI_ADD, &data->SRC_VERIF, &data->PROPSTATUS,
		&data->GCODEFEAT, &data->LOC_DESC, &data->BLGUNTTYP, &data->HSAUNITID,
		&data->BUNIT_PRE1, &data->BUNIT_ID1, &data->BUNIT_SUF1, &data->BUNIT_PRE2,
		&data->BUNIT_ID2, &data->BUNIT_SUF2, &data->FLOOR_TYPE, &data->FLOOR_NO_1,
		&data->FLOOR_NO_2, &data->BUILDING, &data->COMPLEX, &data->HSE_PREF1,
		&data->HSE_NUM1, &data->HSE_SUF1, &data->HSE_PREF2, &data->HSE_NUM2,
		&data->HSE_SUF2, &data->DISP_NUM1, &data->ROAD_NAME, &data->ROAD_TYPE,
		&data->RD_SUF, &data->LOCALITY, &data->STATE, &data->POSTCODE,
		&data->ACCESSTYPE
	};

	// First, read all the string fields [that only works here where all string fields are adjacent]
	for (int i = 0; i < NUMBER_OF_STRING_FIELDS; i++) {
		int in_quotes = 0;
		fieldStart = current;

		// Find the end of the current field
		// using in_quote to accept commas (,) within the quotted texts
		while (*current != '\0' && (in_quotes || (*current != ',' && *current != '\n'))) {
			if (*current == '"') {
				in_quotes = !in_quotes; // Toggle quote state
			}
			current++;
		}

		// Null-terminate the field
		char *fieldEnd = current;
		// If the field was quoted, point to the character after the opening quote
		if (*fieldStart == '"' && *(fieldEnd - 1) == '"') {
			*(fieldEnd - 1) = '\0';
			*fieldPtrs[i] = fieldStart + 1;
		} else {
			// Otherwise, point directly to the start of the field
			*fieldEnd = '\0';
			*fieldPtrs[i] = fieldStart;
		}
		
		// Move to the next char
		current++;
	}

	// The remaining data in the buffer should be the two long double fields
	data->x = strtold(current, &current);
	if (*current == ',') {
		current++;
	}
	data->y = strtold(current, NULL);

	return data;
}

/*
 * Prints a data_t to a specified file stream.
 * Each field is printed in the format "field_name: value ||", including the last field
 *
 * Input:
 *     outfile:  A pointer to the FILE stream to write to.
 *     data   :  A pointer to the data_t struct to be printed.
 */
void dataPrint(FILE *outfile, data_t *data) {
	if (!data || !outfile) {
		return; // Handle null pointers gracefully
	}

	// An array of the string fields in the struct. 
	//    Used for simplifying the code for printing  

	char *fieldData[] = {
		data->PFI, data->EZI_ADD, data->SRC_VERIF, data->PROPSTATUS,
		data->GCODEFEAT, data->LOC_DESC, data->BLGUNTTYP, data->HSAUNITID,
		data->BUNIT_PRE1, data->BUNIT_ID1, data->BUNIT_SUF1, data->BUNIT_PRE2,
		data->BUNIT_ID2, data->BUNIT_SUF2, data->FLOOR_TYPE, data->FLOOR_NO_1,
		data->FLOOR_NO_2, data->BUILDING, data->COMPLEX, data->HSE_PREF1,
		data->HSE_NUM1, data->HSE_SUF1, data->HSE_PREF2, data->HSE_NUM2,
		data->HSE_SUF2, data->DISP_NUM1, data->ROAD_NAME, data->ROAD_TYPE,
		data->RD_SUF, data->LOCALITY, data->STATE, data->POSTCODE,
		data->ACCESSTYPE
	};
	
	// An array of the corresponding field names for printing.
	char *fieldNames[] = {
		"PFI", "EZI_ADD", "SRC_VERIF", "PROPSTATUS", "GCODEFEAT", "LOC_DESC",
		"BLGUNTTYP", "HSAUNITID", "BUNIT_PRE1", "BUNIT_ID1", "BUNIT_SUF1",
		"BUNIT_PRE2", "BUNIT_ID2", "BUNIT_SUF2", "FLOOR_TYPE", "FLOOR_NO_1",
		"FLOOR_NO_2", "BUILDING", "COMPLEX", "HSE_PREF1", "HSE_NUM1",
		"HSE_SUF1", "HSE_PREF2", "HSE_NUM2", "HSE_SUF2", "DISP_NUM1",
		"ROAD_NAME", "ROAD_TYPE", "RD_SUF", "LOCALITY", "STATE", "POSTCODE",
		"ACCESSTYPE"
	};

	// Loop through the array and print each string field.
	for (int i = 0; i < NUMBER_OF_STRING_FIELDS; i++) {
		fprintf(outfile, "%s: %s || ", fieldNames[i], fieldData[i]);
	}

	// Print the final two long double fields with the specified format.
	fprintf(outfile, "x: %.5Lf || y: %.5Lf || \n", data->x, data->y);
}



/*
 * Compares two strings bit-by-bit, similar to a lexicographical comparison
 * but on individual bits. The length is also considered. It returns the
 * comparison result and also records the number of bit comparisons.
 *
 * Input:
 *      key: A null-terminated string to compare against the EZI_ADD field.
 *      data: A pointer to a data_t data.
 *      bitcmp: A pointer to a size_t variable to store the number of bit comparisons.
 * Return:
*        -1 if key is less than data->EZI_ADD, 0 if they are equal, and 1 if key is greater.
 */
int keycmp(char *key, data_t *data, size_t *bitcmp) {
	// Handle invalid input
	if (!key || !data || !data->_KEY || !bitcmp) {
		fprintf(stderr, "Invalid call to keycmp\n");
		exit(EXIT_FAILURE);
	}

	*bitcmp = 0;

	size_t keyLen = strlen(key)+1;
	size_t fieldLen = strlen(data->_KEY)+1;
	size_t maxBitCmp = keyLen * BITS_PER_BYTE;

	// Determine the number of bits to compare based on the shorter string
	if (fieldLen * BITS_PER_BYTE < maxBitCmp) {
		maxBitCmp = fieldLen * BITS_PER_BYTE;
	}
	
	// Compare bit-by-bit up to the length of the shorter string
	for (size_t i = 0; i < maxBitCmp; i++) {
		// Increment bit comparisons
		(*bitcmp)++;

		int keyBit = getBit(key, i);
		int fieldBit = getBit(data->_KEY, i);
		if (keyBit > fieldBit) {
			// Key is greater, return 1
			return 1;
		}
		if (keyBit < fieldBit) {
			// Key is less, return -1
			return -1;
		}
	}
	
	// If a full prefix match is found, compare by length
	if (keyLen > fieldLen) {
		return 1;
	}
	if (keyLen < fieldLen) {
		return -1;
	}

	// If all bits are equal and lengths are identical, they are a perfect match
	return 0;
}

void dataFree(data_t *data) {
	assert(data);
	if (data->storage) {
		free(data->storage);
	}
	free(data);
}


