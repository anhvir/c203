/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemented by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/

// This module was basically copied from W3.4.(list.c, list.h) 

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "data.h"
#include "list.h"

void error(char *name) {
	fprintf(stderr, "Function %s not yet implemented.\n", name);
	exit(EXIT_FAILURE);
}

// data definitions, internal within list.checks >>>>>>>>>>>>>>>>>>>>>>>>>>
// a list node 
typedef struct node node_t;
struct node {
	void *data;              // points to the data element of the node
	node_t *next;            // points to the next node in the list
};

// a linked list is defined as a couple of pointers
struct list {
	node_t *head;  // points to the first node of the list
	node_t *tail;  // points to the last node of the list 
	size_t n;               // number of element in the list
};


// generous functions >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// creates & returns an empty linked list
list_t *listCreate() {
	list_t *list = malloc(sizeof(*list));
	assert(list);
	list->head = list->tail = NULL;
	list->n = 0;
	return list;
}

// free the list, including the data inside nodes
void listFree(list_t *list) {
	assert(list != NULL);
	node_t *curr = list->head; // curr points to the first node
	while (curr) {             // while curr not reaching the end of list
		node_t *tmp = curr;
		curr = curr->next;     // advance curr to the next next node 
		if (tmp->data) dataFree(tmp->data);       // frees the previous node including
		free(tmp);             //    freeing the space used by data
	}
	free(list);                // free the list itself
} 

// free the list, but NOT the data inside nodes
void listFreeNoData(list_t *list){ 
	assert(list != NULL);
	node_t *curr = list->head; // curr points to the first node
	while (curr) {             // while curr not reaching the end of list
		node_t *tmp = curr;
		curr = curr->next;     // advance curr to the next next node 
		free(tmp);             //    freeing the space used by data
	}
	free(list);                // free the list itself
} 

// returns 1 if the list is empty, 0 otherwise
int listIsEmpty(list_t *list) {
	assert(list);
	return list->head == NULL;
}

// returns the number of elements in list
size_t listCount(list_t *list){
	assert(list);
	return list->n;
}

// functions for insertion >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// inserts a new node with value "data" to the end of "list" 
void listAppend(list_t *list, void *data) {
	assert(list);

	// creates a new node and set data 
	node_t *new = malloc(sizeof(*new));
	assert(new);
	new->data = data;
	new->next = NULL;                // "new" is the terminating node!
	if (list->head == NULL) {          // if the original list is empty
		// "new" becomes the only node of the list
		list->head = list->tail = new;
	} else {
		list->tail->next = new;  // connects the tail node to "new"
		list->tail = new;        // repairs the pointer "tail"
	}

	// updates the number of elements in the list
	(list->n)++;
}

void *listGetFirst(list_t *list) {
	assert(list && list->head);
	return list->head->data;
}

// performs linear search in "list", find all exactly matched records 
// return a reslt_t * that also contains some search statistics 
result_t *listFindAll(list_t *dict, char *query) {
	result_t *res= resultCreate(query);	
	assert (dict && query && res);
	list_t *soln = NULL;

	for (node_t *p = dict->head; p; p = p->next) {
		size_t bits= 0;
		(res->strings)++;
		(res->nodes)++;
		if ( keycmp(query, p->data, &bits)==0 ) {
			if (!soln ) soln= listCreate(); 
			listAppend(soln, p->data);
		}
		res->bits += bits;
	}

	res->soln= soln;
	return res;
}


// print data off all nodes, in order
void listOutputAll(FILE *f, list_t *l, char *prefix) {
	assert (f && l && prefix);

	for (node_t *p = l->head; p; p = p->next) {
		fprintf(f, "%s",prefix);
		dataPrint(f, p->data);
	}
}


