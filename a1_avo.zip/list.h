/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemented by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/

// This is module was basically copied from W3.4.(list.c, list.h) 

#ifndef _LIST_H_
#define _LIST_H_
#include "data.h"
#include "result.h"

// type definitions >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
typedef struct list list_t;


// generous functions >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// creates & returns an empty linked list
list_t *listCreate();

// free the list, including the data inside nodes
void listFree(list_t *list);

// free the list, but NOT the data inside nodes
void listFreeNoData(list_t *list);

// returns 1 if the list is empty, 0 otherwise
int listIsEmpty(list_t *list); 

// returns the number of elements in list
size_t listCount(list_t *list);

// functions for insertion >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// inserts a new node with value "data" to the end of "list" 
void listAppend(list_t *list, void *data); 

// functions for getting the first element of the list 
void *listGetFirst(list_t *list);

// performs linear search in "list", find all exactly matched records 
// here we assume that key is char * and
result_t *listFindAll(list_t *dict, char *query);

void listOutputAll(FILE *f, list_t *l, char *prefix);

#endif



