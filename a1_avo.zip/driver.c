/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemented by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>

#include "result.h"
#include "data.h"
#include "list.h"

int processArgs(int argc, char *argv[]);

list_t *buildList(char *filename);
void listDict(char *inputFile, FILE *outFile, FILE *statFile);

int main(int argc, char *argv[]) {
	int dictType= processArgs(argc, argv);
	FILE *outFile = fopen(argv[3], "w");  //  result output 
	assert (outFile);
	FILE *statFile = stdout;              // statistics output

	switch(dictType) {
		case 1:
			listDict(argv[2], outFile, statFile);
			break;
		case 2:
			// working with Patricia trie?
			break; 
	}

	fclose(outFile);
	return 0;
}

// makes sure to have enough arguments in the command line
// returns the specified dictionnary type
// adapted from W3.4-main.c
int processArgs(int argc, char *argv[]) {
	int dictType;
	if (argc < 4 || (dictType=atoi(argv[1]))<1 || dictType>2 ) {
		fprintf(stderr, "Usage: %s|2 1|2 input_CSV_file_name output_file_name, where:\n", argv[0]);
		fprintf(stderr, "       \t - input_CSV_file_name: data file for buiding dictionary\n");
		fprintf(stderr, "       \t - output_file_name: a file for outputing search resul\n");
		exit(EXIT_FAILURE);
	}
	return dictType;
}

/*--------FUNCTIONS FOR WORKING WITH LINKED LIST DICT   -------------------------*/

void listDict(char *inputFile, FILE *outFile, FILE *statFile) {
	// build linked list of data
	list_t *dict= buildList(inputFile);

	// loop to get query and process 
	char query[MAX_LINE_LEN];
	while (fgets(query, MAX_LINE_LEN, stdin)) {
		if (query[strlen(query)-1]=='\n') {
			query[strlen(query)-1]= '\0';
		}
		result_t *result= listFindAll(dict, query);		
		resultPrint(result, outFile, statFile);
		resultFree(result);
	}
	listFree(dict);
}	



// reads datas from "filename", 
// returns lined list of datas
// copied from W3.4-main.c
list_t *buildList(char *filename) {
	FILE *f = fopen(filename, "r");
	assert(f);
	list_t *datas = listCreate();
	dataSkipHeaderLine(f);
	data_t *s;
	while ((s = dataBuild(f))) {
		listAppend(datas, s);
	}
	fclose(f);
	return datas;
}



