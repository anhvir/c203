/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemente by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/

#ifndef _RESULT_H_
#define _RESULT_H_
#include <stdio.h>

// note: this struct definition should be in result.c 
//       it was placed here for direct update of components
//           when doing search
//       An alternative way is:
//           - plce this in result.c , but
//           - supply a function for updating the components


struct result {
    char *key;              // full key to search for 
    void *soln;             // DS (linked list) for matching records
    size_t bits;            // number of bit comparisons, 
    size_t strings;         //           string
    size_t nodes;           //           node
};

typedef struct result result_t;
result_t * resultCreate(char *key);
void resultPrint(result_t *res, FILE *outFile, FILE *statFile);
void resultFree(result_t *res);
void resultFreeNoFreeSoln(result_t *res);

#endif


