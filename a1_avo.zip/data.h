/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemented by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/

#ifndef _DATA_H_
#define _DATA_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "bit.h"

#define MAX_LINE_LEN 513   /* include \n and \0 */


struct data;           // description is in data.c
typedef struct data data_t;
/* 
	skip the header line of .csv file "f"
	Copied from W3.4
*/
void dataSkipHeaderLine(FILE *infile);
char *dataGetKey(data_t *data);

/*
 * Reads a single line from a file stream, parses it as a CSV data,
 * and creates a new data_t struct. 
 *
 * Input:
	   infile:  A pointer to the FILE stream to read from.
 * Return:
	   A pointer to the newly allocated data_t struct, or NULL on error or EOF.
 * Limitation:
	   A single CSV input line should contain all fields of a data 
	   (that is, no \n allowed inside any field)
	   If a field contains an opening ", it must have a coresponging closing "
 */
data_t *dataBuild(FILE *infile);

/*
 * Prints a data_t to a specified file stream.
 * Each field is printed in the format "field_name: value ||", including the last field
 *
 * Input:
 *     outfile:  A pointer to the FILE stream to write to.
 *     data   :  A pointer to the data_t struct to be printed.
 */
void dataPrint(FILE *outfile, data_t *data);

/*
 * Compares two strings bit-by-bit, similar to a lexicographical comparison
 * but on individual bits. The length is also considered. It returns the
 * comparison result and also records the number of bit comparisons.
 *
 * Input:
 *      key: A null-terminated string to compare against the EZI_ADD field.
 *      data: A pointer to a data_t data.
 *      bitcmp: A pointer to a size_t variable to store the number of bit comparisons.
 * Return:
*        -1 if key is less than data->EZI_ADD, 0 if they are equal, and 1 if key is greater.
 */
int keycmp(char *key, data_t *data, size_t *bitcmp);

void dataFree(data_t *data);
void dataPrint(FILE *outfile, data_t *data);

#endif  /* #ifndef */
