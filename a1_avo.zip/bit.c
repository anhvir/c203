/*-------------------------------------------------------------- 
 *..Project: dict1, for Assignment1, comp20003 25s2
 *  Implemented by avo@unimelb.edu.au
 *. Last updated: 10 AUG 2025
 *
 *  data.h, data.c :  
		  the implementation of module data (address data) of the project
	list.h, list.c:
		.. implementation of linked lists, mostly copied from W3.4
	bit.c bit.h
		.. implementation of tools for working with bit level
	result.c result.h 
        .. tools for storing/processing search output
    driver.c:
		.. the main() function 
 * 
 *----------------------------------------------------------------*/
// avo@unimelb.edu.au, 05 AUG 2025
//   - adapted from the original bit.c distributed in  Assignment1 
//     add small change for simplicity  




#include <stdlib.h>
#include <assert.h>
#include "bit.h"

/*
 * Returns the value of a specific bit from a character string.
 *
 * Input:
 *    s          The input string
 *    bitIndex   The index of the bit of interest, starting from 0.
 */
int getBit(const char *s, unsigned int bitIndex) {
    // Assert that the string pointer is not NULL and the bit index is within bounds.
    assert(s != NULL);
    // Note: due to the need for effciency, bitIndex is not checked for its upper bound 
    //       there is no need for checking lower bound because "unsigned int" is >=0

    // Calculate the index of the byte that contains the bit of interest.
    unsigned int byteIndex = bitIndex / BITS_PER_BYTE;
    // Calculate the position from left of the bit within that byte.
    unsigned int bitPosition = bitIndex % BITS_PER_BYTE;
    // Extract the byte.
    unsigned char byte = s[byteIndex];
    // Shift the bit of interest to the rightmost position and use a bitwise AND to isolate it.
    return (byte >> (BITS_PER_BYTE - 1 - bitPosition)) & 1;
}

